#!/bin/bash

cd "$(dirname "$0")"

# === Get ngrok config ===
if [ -z "$NGROK_TOKEN" ]; then
  read -p "🔐 Enter your ngrok authtoken: " NGROK_TOKEN
fi

if [ -z "$NGROK_DOMAIN" ]; then
  read -p "🌐 Enter your ngrok domain (e.g. custom-subdomain.ngrok.app): " NGROK_DOMAIN
fi

export NGROK_TOKEN
export NGROK_DOMAIN
export DOMAIN="$NGROK_DOMAIN"
export SAFE_DOMAIN=$(echo "$NGROK_DOMAIN" | sed 's|https://||g' | sed 's|[-.]|_|g')

# === Identity ===
UUID=$(cat /proc/sys/kernel/random/uuid)
USER_ID="orch-${UUID}"
TIMESTAMP=$(date -u +%Y-%m-%dT%H:%M:%SZ)

mkdir -p /tmp/orchestrate
echo "{\"user_id\": \"$USER_ID\", \"installed_at\": \"$TIMESTAMP\"}" > /tmp/orchestrate/system_identity.json

# === Ledger ===
BIN_ID="68292fcf8561e97a50162139"
API_KEY="\$2a\$10\$MoavwaWsCucy2FkU/5ycV.lBTPWoUq4uKHhCi9Y47DOHWyHFL3o2C"

# === Wait for referrer.txt if needed ===
for i in {1..3}; do
  if [ -f "referrer.txt" ]; then
    break
  fi
  sleep 1
done

if [ -f "referrer.txt" ]; then
  REFERRER_ID=$(cat referrer.txt)
else
  REFERRER_ID=""
fi

LEDGER=$(curl -s -X GET "https://api.jsonbin.io/v3/b/$BIN_ID/latest" -H "X-Master-Key: $API_KEY")
INSTALLS=$(echo "$LEDGER" | jq '.record.installs')

INSTALLS=$(echo "$INSTALLS" | jq --arg uid "$USER_ID" --arg ts "$TIMESTAMP" \
  '.[$uid] = {
    referral_count: 0,
    referral_credits: 0,
    tools_unlocked: ["json_manager"],
    timestamp: $ts
  }')

if [ "$REFERRER_ID" != "" ]; then
  INSTALLS=$(echo "$INSTALLS" | jq --arg rid "$REFERRER_ID" \
    'if .[$rid] != null then
      .[$rid].referral_count += 1 |
      .[$rid].referral_credits += 1
     else . end')
fi

FINAL=$(jq -n --argjson installs "$INSTALLS" '{filename: "install_ledger.json", installs: $installs}')
echo "$FINAL" | curl -s -X PUT "https://api.jsonbin.io/v3/b/$BIN_ID" \
  -H "Content-Type: application/json" \
  -H "X-Master-Key: $API_KEY" \
  --data @-

echo '{ "referral_count": 0, "referral_credits": 0, "tools_unlocked": ["json_manager"] }' > /tmp/orchestrate/referrals.json

# === Clone runtime to hidden location ===
if [ ! -d "/opt/orchestrate-core-runtime" ]; then
  git clone https://github.com/unmistakablecreative/orchestrate-core-runtime.git /opt/orchestrate-core-runtime
fi

cd /opt/orchestrate-core-runtime

# === OpenAPI & instructions ===
envsubst < openapi_template.yaml > /app/openapi.yaml
envsubst < instructions_template.json > /app/custom_instructions.json

echo "📎 === CUSTOM INSTRUCTIONS ===" > /app/_paste_into_gpt.txt
cat /app/custom_instructions.json >> /app/_paste_into_gpt.txt
echo -e "\n\n📎 === OPENAPI.YAML ===" >> /app/_paste_into_gpt.txt
cat /app/openapi.yaml >> /app/_paste_into_gpt.txt

# === Start tunnel and server ===
ngrok config add-authtoken "$NGROK_TOKEN"
ngrok http --domain="$NGROK_DOMAIN" 8000 > /dev/null &

sleep 3
export REFERRAL_RELAY_URL="https://referral-relay-fzc4u40pd-srinivas-rao-s-projects.vercel.app/referral"

exec uvicorn jarvis:app --host 0.0.0.0 --port 8000
